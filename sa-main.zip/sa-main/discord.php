<?php

Header('Location: https://discord.gg/aQpVxkdn');

?>