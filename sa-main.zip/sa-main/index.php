<?php

Header('Location: ../404.html');

?>