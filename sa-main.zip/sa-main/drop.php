 <div class="content-header-right text-md-end col-md-3 col-12 d-md-block d-none">
                    <div class="mb-1 breadcrumb-right">
                        <div class="dropdown">
                            <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="grid"></i></button>
                            <div class="dropdown-menu dropdown-menu-end"><a class="dropdown-item" href="terminal"><i class="me-1" data-feather="terminal"></i><span class="align-middle">Terminal</span></a><a class="dropdown-item" href="gorevler"><i class="me-1" data-feather="calendar"></i><span class="align-middle">Görevler</span></a><a class="dropdown-item" href="email"><i class="me-1" data-feather="mail"></i><span class="align-middle">Email</span></a><a class="dropdown-item" href="https://discord.gg/aQpVxkdn" target="_blank"><i class="me-1" data-feather="chrome"></i><span class="align-middle">Discord</span></a></div>
                        </div>
                    </div>
                </div>